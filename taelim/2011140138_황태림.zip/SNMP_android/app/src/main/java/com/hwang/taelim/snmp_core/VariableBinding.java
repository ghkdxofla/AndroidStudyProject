//package com.hwang.taelim.snmp_core;
//
//import java.util.Vector;
//
//public class VariableBinding extends Vector {
//
//    public VariableBinding(){
//        super();
//    }
//}
